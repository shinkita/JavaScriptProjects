/* Main.Js*/


function colorflipper(){
	document.getElementclass("wrapper_content").style.backgroundColor="green";
	console.log("hello");
}

